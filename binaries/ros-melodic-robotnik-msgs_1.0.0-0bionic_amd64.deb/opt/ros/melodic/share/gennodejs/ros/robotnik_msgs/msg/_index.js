
"use strict";

let named_input_output = require('./named_input_output.js');
let MotorStatus = require('./MotorStatus.js');
let Axis = require('./Axis.js');
let BatteryDockingStatus = require('./BatteryDockingStatus.js');
let LaserMode = require('./LaserMode.js');
let State = require('./State.js');
let Pose2DStamped = require('./Pose2DStamped.js');
let ElevatorAction = require('./ElevatorAction.js');
let MotorPID = require('./MotorPID.js');
let alarmmonitor = require('./alarmmonitor.js');
let BoolArray = require('./BoolArray.js');
let RobotnikMotorsStatus = require('./RobotnikMotorsStatus.js');
let Registers = require('./Registers.js');
let Data = require('./Data.js');
let encoders = require('./encoders.js');
let Pose2DArray = require('./Pose2DArray.js');
let SubState = require('./SubState.js');
let SafetyModuleStatus = require('./SafetyModuleStatus.js');
let ElevatorStatus = require('./ElevatorStatus.js');
let ReturnMessage = require('./ReturnMessage.js');
let MotorsStatusDifferential = require('./MotorsStatusDifferential.js');
let BatteryDockingStatusStamped = require('./BatteryDockingStatusStamped.js');
let InverterStatus = require('./InverterStatus.js');
let Alarms = require('./Alarms.js');
let Cartesian_Euler_pose = require('./Cartesian_Euler_pose.js');
let inputs_outputs = require('./inputs_outputs.js');
let alarmsmonitor = require('./alarmsmonitor.js');
let Register = require('./Register.js');
let MotorsStatus = require('./MotorsStatus.js');
let LaserStatus = require('./LaserStatus.js');
let AlarmSensor = require('./AlarmSensor.js');
let BatteryStatus = require('./BatteryStatus.js');
let MotorHeadingOffset = require('./MotorHeadingOffset.js');
let QueryAlarm = require('./QueryAlarm.js');
let BatteryStatusStamped = require('./BatteryStatusStamped.js');
let StringArray = require('./StringArray.js');
let named_inputs_outputs = require('./named_inputs_outputs.js');
let ptz = require('./ptz.js');
let Interfaces = require('./Interfaces.js');
let SetElevatorAction = require('./SetElevatorAction.js');
let SetElevatorResult = require('./SetElevatorResult.js');
let SetElevatorActionResult = require('./SetElevatorActionResult.js');
let SetElevatorActionFeedback = require('./SetElevatorActionFeedback.js');
let SetElevatorFeedback = require('./SetElevatorFeedback.js');
let SetElevatorActionGoal = require('./SetElevatorActionGoal.js');
let SetElevatorGoal = require('./SetElevatorGoal.js');

module.exports = {
  named_input_output: named_input_output,
  MotorStatus: MotorStatus,
  Axis: Axis,
  BatteryDockingStatus: BatteryDockingStatus,
  LaserMode: LaserMode,
  State: State,
  Pose2DStamped: Pose2DStamped,
  ElevatorAction: ElevatorAction,
  MotorPID: MotorPID,
  alarmmonitor: alarmmonitor,
  BoolArray: BoolArray,
  RobotnikMotorsStatus: RobotnikMotorsStatus,
  Registers: Registers,
  Data: Data,
  encoders: encoders,
  Pose2DArray: Pose2DArray,
  SubState: SubState,
  SafetyModuleStatus: SafetyModuleStatus,
  ElevatorStatus: ElevatorStatus,
  ReturnMessage: ReturnMessage,
  MotorsStatusDifferential: MotorsStatusDifferential,
  BatteryDockingStatusStamped: BatteryDockingStatusStamped,
  InverterStatus: InverterStatus,
  Alarms: Alarms,
  Cartesian_Euler_pose: Cartesian_Euler_pose,
  inputs_outputs: inputs_outputs,
  alarmsmonitor: alarmsmonitor,
  Register: Register,
  MotorsStatus: MotorsStatus,
  LaserStatus: LaserStatus,
  AlarmSensor: AlarmSensor,
  BatteryStatus: BatteryStatus,
  MotorHeadingOffset: MotorHeadingOffset,
  QueryAlarm: QueryAlarm,
  BatteryStatusStamped: BatteryStatusStamped,
  StringArray: StringArray,
  named_inputs_outputs: named_inputs_outputs,
  ptz: ptz,
  Interfaces: Interfaces,
  SetElevatorAction: SetElevatorAction,
  SetElevatorResult: SetElevatorResult,
  SetElevatorActionResult: SetElevatorActionResult,
  SetElevatorActionFeedback: SetElevatorActionFeedback,
  SetElevatorFeedback: SetElevatorFeedback,
  SetElevatorActionGoal: SetElevatorActionGoal,
  SetElevatorGoal: SetElevatorGoal,
};
