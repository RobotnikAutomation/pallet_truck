
"use strict";

let PoseStampedArray = require('./PoseStampedArray.js');
let MoveGoal = require('./MoveGoal.js');
let MoveAction = require('./MoveAction.js');
let MoveActionGoal = require('./MoveActionGoal.js');
let DockActionGoal = require('./DockActionGoal.js');
let MoveActionFeedback = require('./MoveActionFeedback.js');
let DockActionFeedback = require('./DockActionFeedback.js');
let DockGoal = require('./DockGoal.js');
let MoveFeedback = require('./MoveFeedback.js');
let DockFeedback = require('./DockFeedback.js');
let MoveActionResult = require('./MoveActionResult.js');
let DockResult = require('./DockResult.js');
let MoveResult = require('./MoveResult.js');
let DockActionResult = require('./DockActionResult.js');
let DockAction = require('./DockAction.js');

module.exports = {
  PoseStampedArray: PoseStampedArray,
  MoveGoal: MoveGoal,
  MoveAction: MoveAction,
  MoveActionGoal: MoveActionGoal,
  DockActionGoal: DockActionGoal,
  MoveActionFeedback: MoveActionFeedback,
  DockActionFeedback: DockActionFeedback,
  DockGoal: DockGoal,
  MoveFeedback: MoveFeedback,
  DockFeedback: DockFeedback,
  MoveActionResult: MoveActionResult,
  DockResult: DockResult,
  MoveResult: MoveResult,
  DockActionResult: DockActionResult,
  DockAction: DockAction,
};
